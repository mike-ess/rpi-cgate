DEVICE_LIST=`ls -1 /dev/tty* | grep USB | paste -sd ":"`
java -Djava.library.path=. -DSERIAL_PORT_LIST=$DEVICE_LIST -jar cgate.jar